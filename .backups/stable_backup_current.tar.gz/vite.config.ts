import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  // Use relative './' for GitHub Pages builds (supports gate-tehon, gate-tehon-fresh, etc.), while keeping '/' for Cloud Run and local dev
  const isGithubPages = process.env.GITHUB_PAGES === 'true' || process.env.BUILD_TARGET === 'github-pages';
  const basePath = process.env.VITE_BASE_PATH || (isGithubPages ? './' : '/');

  return {
    base: basePath,
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(process.cwd(), '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
